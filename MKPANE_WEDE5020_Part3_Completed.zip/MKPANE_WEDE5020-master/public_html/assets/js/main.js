/* MKPANE website enhancements - client-side interaction and form checks */
(function () {
  'use strict';
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  // Animate content into view while respecting reduced-motion settings.
  const motionOff = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const revealItems = document.querySelectorAll('main section, .content-section, .service-card, .contact-card');
  if (!motionOff && 'IntersectionObserver' in window) {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.08 });
    revealItems.forEach(el => { el.classList.add('reveal'); observer.observe(el); });
  }

  // Filter service cards as the visitor types.
  const search = document.getElementById('serviceSearch');
  if (search) {
    const cards = Array.from(document.querySelectorAll('.service-card'));
    const status = document.getElementById('searchStatus');
    search.addEventListener('input', function () {
      const term = this.value.trim().toLowerCase();
      let shown = 0;
      cards.forEach(card => {
        const match = card.textContent.toLowerCase().includes(term);
        card.hidden = !match;
        if (match) shown++;
      });
      if (status) status.textContent = shown + (shown === 1 ? ' service shown.' : ' services shown.');
    });
  }

  // Validate forms and open a pre-filled email draft. Static GitHub Pages cannot process submissions itself.
  document.querySelectorAll('form').forEach(form => {
    form.addEventListener('submit', function (event) {
      event.preventDefault();
      const old = form.querySelector('.form-feedback');
      if (old) old.remove();
      const feedback = document.createElement('div');
      feedback.className = 'form-feedback error';
      feedback.setAttribute('role', 'alert');
      const fields = Array.from(form.querySelectorAll('input, textarea, select'));
      let firstInvalid = null;
      for (const field of fields) {
        field.setAttribute('aria-invalid', 'false');
        const value = field.value.trim();
        let message = '';
        if (field.required && !value) message = 'Please complete ' + (field.labels?.[0]?.textContent || field.name || 'this field').trim() + '.';
        else if (field.type === 'email' && value && !emailPattern.test(value)) message = 'Please enter a valid email address.';
        else if (field.type === 'tel' && value && !/^[+()\d\s-]{7,20}$/.test(value)) message = 'Please enter a valid phone number (at least 7 digits).';
        if (message) { field.setAttribute('aria-invalid', 'true'); firstInvalid = firstInvalid || field; feedback.textContent = message; break; }
      }
      if (firstInvalid) {
        form.prepend(feedback);
        firstInvalid.focus();
        return;
      }
      const data = new FormData(form);
      const isEnquiry = Boolean(form.querySelector('#service'));
      const subject = isEnquiry ? 'MKPANE Service Enquiry' : 'Message for MKPANE';
      const lines = [];
      data.forEach((value, key) => lines.push(key.replace(/[_-]/g, ' ') + ': ' + value));
      const success = document.createElement('div');
      success.className = 'form-feedback success';
      success.setAttribute('role', 'status');
      success.textContent = 'Your details passed validation. An email draft will open; review it and press Send to submit your message.';
      form.prepend(success);
      const recipient = form.dataset.recipient || '';
      const mailto = 'mailto:' + encodeURIComponent(recipient) + '?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(lines.join('\n'));
      window.location.href = mailto;
    });
  });

  // Interactive map search. The visitor supplies a location because exact MKPANE addresses were not provided.
  const mapInput = document.getElementById('locationSearch');
  const mapButton = document.getElementById('showMap');
  const mapResult = document.getElementById('mapResult');
  if (mapInput && mapButton && mapResult) {
    function loadMap() {
      const place = mapInput.value.trim();
      mapResult.replaceChildren();
      if (!place) {
        const message = document.createElement('p');
        message.textContent = 'Please enter a town, suburb, or address first.';
        mapResult.appendChild(message);
        mapInput.focus();
        return;
      }
      const frame = document.createElement('iframe');
      frame.title = 'Map showing ' + place;
      frame.loading = 'lazy';
      frame.referrerPolicy = 'no-referrer-when-downgrade';
      frame.src = 'https://maps.google.com/maps?q=' + encodeURIComponent(place) + '&output=embed';
      mapResult.appendChild(frame);
      const link = document.createElement('p');
      const anchor = document.createElement('a');
      anchor.href = 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(place);
      anchor.target = '_blank';
      anchor.rel = 'noopener noreferrer';
      anchor.textContent = 'Open this location in Google Maps';
      link.appendChild(anchor);
      mapResult.appendChild(link);
    }
    mapButton.addEventListener('click', loadMap);
    mapInput.addEventListener('keydown', event => { if (event.key === 'Enter') { event.preventDefault(); loadMap(); } });
  }

  // Back-to-top control.
  const topButton = document.createElement('button');
  topButton.type = 'button';
  topButton.className = 'back-to-top';
  topButton.setAttribute('aria-label', 'Back to top');
  topButton.title = 'Back to top';
  topButton.textContent = '↑';
  document.body.appendChild(topButton);
  window.addEventListener('scroll', () => topButton.classList.toggle('visible', window.scrollY > 450), { passive: true });
  topButton.addEventListener('click', () => window.scrollTo({ top: 0, behavior: motionOff ? 'auto' : 'smooth' }));
})();
